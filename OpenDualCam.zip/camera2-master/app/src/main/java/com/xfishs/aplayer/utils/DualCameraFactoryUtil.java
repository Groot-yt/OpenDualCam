package com.xfishs.aplayer.utils;

import android.content.Context;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraManager;
import android.util.Log;

import java.util.Arrays;
import java.util.Set;

public class DualCameraFactoryUtil {

    private final static String TAG = "DualCameraFactoryUtil";


    /**
     * 获取双镜类
     * @param context
     * @return
     *
     * 公司的一些机器上屏蔽了camera的暴露数量，只露出了主摄和前摄
     * 需要设置一下属性：
     *      setprop vendor.camera.aux.packagelist "com.xfishs.aplayer"
     *  调试完之后记得还原回去，避免影响系统camera的运行：
     *      setprop vendor.camera.aux.packagelist "com.android.engtest,com.android.camera2,com.mediatek.emcamera,com.mediatek.camera"
     */
    public static DualCamera getDualCamera(Context context){
        DualCamera dualCamera = new DualCamera();
        //获取管理类
        CameraManager manager = (CameraManager) context.getSystemService(Context.CAMERA_SERVICE);
        assert manager != null;
        try {
            //获取所有逻辑ID
            String[] cameraIdList = manager.getCameraIdList();
            Log.d("yutao", "cameraIdList: " + cameraIdList.length);
            //获取逻辑摄像头下拥有多个物理摄像头的类 作为双镜类
            for (String id : cameraIdList) {
                Log.d(TAG, "id: " + id);
                try {
                    CameraCharacteristics cameraCharacteristics = manager.getCameraCharacteristics(id);
                    Set<String> physicalCameraIds = cameraCharacteristics.getPhysicalCameraIds();
                    Log.d(TAG, "逻辑ID：" + id + " 下的物理ID: " + Arrays.toString(physicalCameraIds.toArray()));
                    if (physicalCameraIds.size() >= 2) {
                        dualCamera.setLogicCameraId(id);
                        Object[] objects = physicalCameraIds.toArray();
                        //获取前两个物理摄像头作为双镜头
                        dualCamera.setPhysicsCameraId1(String.valueOf(objects[0]));
                        dualCamera.setPhysicsCameraId2(String.valueOf(objects[1]));
                        return dualCamera;
                    }
                } catch (CameraAccessException e) {
                    e.printStackTrace();
                }
            }
            /*
                正常的执行log如下
            *    cameraIdList: 6
                 id: 0
                 逻辑ID：0 下的物理ID: []
                 id: 1
                 逻辑ID：1 下的物理ID: []
                 id: 2
                 逻辑ID：2 下的物理ID: []
                 id: 3
                 逻辑ID：3 下的物理ID: []
                 id: 4
                 逻辑ID：4 下的物理ID: []
                 id: 5
                 逻辑ID：5 下的物理ID: [0, 2]
            * */
        } catch (CameraAccessException e) {
            e.printStackTrace();
        }
        return null;
    }



}
