package com.xfishs.aplayer;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.media.projection.MediaProjectionManager;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.TextureView;
import android.view.View;
import android.view.ViewGroup;

import com.xfishs.aplayer.utils.DualCamera;
import com.xfishs.aplayer.utils.DualCameraController;
import com.xfishs.aplayer.utils.DualCameraFactoryUtil;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class AFragment extends Fragment {
    private static final String TAG = "AFragment";

    private static final int PERMISSIONS_REQUEST_CODE = 100;
    //双镜控制类
    private DualCameraController dualCameraController;
    //页面显示类
    private List<TextureView> mTextureViews;


    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle
            savedInstanceState) {
        View v = inflater.inflate(R.layout.activity_main, container, false);
        //初始化组件
        findView(v);
        //权限检查
        if (ActivityCompat.checkSelfPermission(getContext(), Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED &&
                ActivityCompat.checkSelfPermission(getContext(), Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            openDualCamera();
        } else {
            //否则去请求相机权限
            ActivityCompat.requestPermissions(getActivity(), new String[]{Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO}, PERMISSIONS_REQUEST_CODE);
        }
        return v;
    }

    //打开双镜
    private void openDualCamera() {
        //获取双镜类
        DualCamera dualCamera = DualCameraFactoryUtil.getDualCamera(getActivity());
        //打开双镜
        dualCameraController = new DualCameraController(getActivity(), mTextureViews.get(0), mTextureViews.get(1), dualCamera);
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        //销毁组件
        dualCameraController.onDestroyView();
    }


    //初始化组件
    private void findView(View view) {
        mTextureViews = new ArrayList<>();
        List<Integer> ids = Arrays.asList(R.id.tv_textview0, R.id.tv_textview1);
        ids.forEach(v -> mTextureViews.add(view.findViewById(v)));
        view.findViewById(R.id.record_btn).setOnClickListener( v -> {
            //dualCameraController.handleRecord();
            screenRecord();
        });
    }

    private void screenRecord() {
        MediaProjectionManager mediaProjectionManager = (MediaProjectionManager) getActivity().getSystemService(Context.MEDIA_PROJECTION_SERVICE);
        Intent permissionIntent = mediaProjectionManager.createScreenCaptureIntent();
        startActivityForResult(permissionIntent, 1000);
    }

    //权限检查回执


    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        switch (requestCode) {
            case PERMISSIONS_REQUEST_CODE:
                if (permissions[0].equals(Manifest.permission.CAMERA)) {
                    if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                        //同意了再去打开相机
                        openDualCamera();
                    }
                }
                break;
            default:
                throw new IllegalStateException("Unexpected value: " + requestCode);
        }
    }
}
