package com.xfishs.aplayer.utils;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.SurfaceTexture;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraCaptureSession;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraDevice;
import android.hardware.camera2.CameraManager;
import android.hardware.camera2.CameraMetadata;
import android.hardware.camera2.CaptureRequest;
import android.hardware.camera2.params.OutputConfiguration;
import android.hardware.camera2.params.SessionConfiguration;
import android.hardware.camera2.params.StreamConfigurationMap;
import android.media.MediaRecorder;
import android.media.projection.MediaProjectionManager;
import android.os.AsyncTask;
import android.os.Handler;
import android.os.HandlerThread;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.util.Log;
import android.util.Size;
import android.util.SparseIntArray;
import android.view.Surface;
import android.view.TextureView;
import android.widget.Toast;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;


public class DualCameraController {
    private static final String TAG = "DualCameraController";

    private static final Integer PERMISSIONS_REQUEST_CODE = 1000;

    private static final int SENSOR_ORIENTATION_DEFAULT_DEGREES = 90;
    private static final int SENSOR_ORIENTATION_INVERSE_DEGREES = 270;

    private static final SparseIntArray DEFAULT_ORIENTATIONS = new SparseIntArray();
    private static final SparseIntArray INVERSE_ORIENTATIONS = new SparseIntArray();

    static {
        DEFAULT_ORIENTATIONS.append(Surface.ROTATION_0, 90);
        DEFAULT_ORIENTATIONS.append(Surface.ROTATION_90, 0);
        DEFAULT_ORIENTATIONS.append(Surface.ROTATION_180, 270);
        DEFAULT_ORIENTATIONS.append(Surface.ROTATION_270, 180);
    }

    static {
        INVERSE_ORIENTATIONS.append(Surface.ROTATION_0, 270);
        INVERSE_ORIENTATIONS.append(Surface.ROTATION_90, 180);
        INVERSE_ORIENTATIONS.append(Surface.ROTATION_180, 90);
        INVERSE_ORIENTATIONS.append(Surface.ROTATION_270, 0);
    }

    //两个 预览组件
    private TextureView textureView1;
    private TextureView textureView2;
    //session
    private CameraCaptureSession cameraSession;
    //上下文
    private Activity context;
    //双镜
    private DualCamera dualCamera;
    //hanlder
    private Handler mBackgroundHandler;

    private CameraDevice mCameraDevice;
    private Integer mSensorOrientation = SENSOR_ORIENTATION_DEFAULT_DEGREES;
    private MediaRecorder mMediaRecorder;
    private boolean mIsRecordingVideo;

    private String mNextVideoAbsolutePath;
    private CaptureRequest.Builder mPreviewBuilder;

    int mWidth, mHeight;
    public DualCameraController(Activity context, TextureView textureView1,TextureView textureView2,DualCamera dualCamera){
        this.context = context;
        this.textureView1 = textureView1;
        this.textureView2 = textureView2;
        this.dualCamera = dualCamera;
        this.textureView2.setSurfaceTextureListener(surfaceTextureListener2);
        this.textureView1.setSurfaceTextureListener(surfaceTextureListener1);
    }

    private TextureView.SurfaceTextureListener surfaceTextureListener1 =  new TextureView.SurfaceTextureListener() {
        @Override
        public void onSurfaceTextureAvailable(SurfaceTexture surface, int width, int height) {
            //必须是在此处开启摄像头，
            //原因： 这个方法 是在SurfaceTexture （ui） 准备好后执行。   避免报null。
            //openCamera();
            Log.d("yutao", "surface1, width: " + width + ", height: " + height);
            mWidth = width;
            mHeight = height;
        }

        @Override
        public void onSurfaceTextureSizeChanged(SurfaceTexture surface, int width, int height) {
        }
        @Override
        public boolean onSurfaceTextureDestroyed(SurfaceTexture surface) {
            return false;
        }
        @Override
        public void onSurfaceTextureUpdated(SurfaceTexture surface) {
        }
    };

    //mTextureView 的监听器
    private TextureView.SurfaceTextureListener surfaceTextureListener2 =  new TextureView.SurfaceTextureListener() {
        @Override
        public void onSurfaceTextureAvailable(SurfaceTexture surface, int width, int height) {
            //必须是在此处开启摄像头，
            //原因： 这个方法 是在SurfaceTexture （ui） 准备好后执行。   避免报null。
            Log.d("yutao", "surface2, width: " + width + ", height: " + height);
            openCamera();
        }

        @Override
        public void onSurfaceTextureSizeChanged(SurfaceTexture surface, int width, int height) {
        }
        @Override
        public boolean onSurfaceTextureDestroyed(SurfaceTexture surface) {
            return false;
        }
        @Override
        public void onSurfaceTextureUpdated(SurfaceTexture surface) {
        }
    };


    //开启摄像头
    public void openCamera(){
        HandlerThread thread = new HandlerThread("DualCeamera");
        thread.start();
        mBackgroundHandler = new Handler(thread.getLooper());
        CameraManager manager = (CameraManager) context.getSystemService(Context.CAMERA_SERVICE);
        try {
            //权限检查
            if (ActivityCompat.checkSelfPermission(context, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                //否则去请求相机权限
                ActivityCompat.requestPermissions(context,new String[]{Manifest.permission.CAMERA},PERMISSIONS_REQUEST_CODE);
                return;
            }
            mMediaRecorder = new MediaRecorder();
            manager.openCamera(dualCamera.getLogicCameraId(),AsyncTask.SERIAL_EXECUTOR, cameraOpenCallBack);
        } catch (CameraAccessException e) {
            e.printStackTrace();
        }
    }

    //打开相机时候的监听器，通过他可以得到相机实例，这个实例可以创建请求建造者
    private CameraDevice.StateCallback cameraOpenCallBack = new CameraDevice.StateCallback() {
        @Override
        public void onOpened(CameraDevice cameraDevice) {
            Log.d(TAG, "相机已经打开");
            //当逻辑摄像头开启后， 配置物理摄像头的参数
            mCameraDevice = cameraDevice;
            startPreview();
        }

        @Override
        public void onDisconnected(@NonNull CameraDevice cameraDevice) {
            Log.d(TAG, "相机连接断开");
        }

        @Override
        public void onError(@NonNull CameraDevice cameraDevice, int i) {
            Log.d(TAG, "相机打开失败");
        }
    };


    /**
     * 配置摄像头参数
     */
    public void startPreview(){
        try {
            //构建输出参数  在参数中设置物理摄像头
            List<OutputConfiguration> configurations = new ArrayList<>();
            mPreviewBuilder = mCameraDevice.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW);

            //配置第一个物理摄像头
            SurfaceTexture texture = textureView1.getSurfaceTexture();
            OutputConfiguration outputConfiguration = new OutputConfiguration(new Surface(texture));
            outputConfiguration.setPhysicalCameraId(dualCamera.getPhysicsCameraId1());
            configurations.add(outputConfiguration);
            mPreviewBuilder.addTarget(Objects.requireNonNull(outputConfiguration.getSurface()));

            //配置第2个物理摄像头
            SurfaceTexture texture2 = textureView2.getSurfaceTexture();
            OutputConfiguration outputConfiguration2 = new OutputConfiguration(new Surface(texture2));
            outputConfiguration2.setPhysicalCameraId(dualCamera.getPhysicsCameraId2());
            configurations.add(outputConfiguration2);
            mPreviewBuilder.addTarget(Objects.requireNonNull(outputConfiguration2.getSurface()));

            //注册摄像头
            SessionConfiguration sessionConfiguration = new SessionConfiguration(
                    SessionConfiguration.SESSION_REGULAR,
                    configurations,
                    AsyncTask.SERIAL_EXECUTOR,
                    new CameraCaptureSession.StateCallback() {
                        @Override
                        public void onConfigured(@NonNull CameraCaptureSession cameraCaptureSession) {
                            try {
                                cameraSession = cameraCaptureSession;
                                cameraCaptureSession.setRepeatingRequest(mPreviewBuilder.build(), null, mBackgroundHandler);
                            } catch (CameraAccessException e) {
                                e.printStackTrace();
                            }
                        }
                        @Override
                        public void onConfigureFailed(@NonNull CameraCaptureSession cameraCaptureSession) {

                        }
                    }
            );
            mCameraDevice.createCaptureSession(sessionConfiguration);
        } catch (CameraAccessException e) {
            e.printStackTrace();
        }
    }


    //当页面关闭的时候 关闭页面
    public void onDestroyView() {
        if (cameraSession != null) {
            cameraSession.getDevice().close();
            cameraSession.close();
        }
    }

    public void handleRecord() {
        if (mIsRecordingVideo) {
            stopRecordingVideo();
        } else {
            //startRecordingVideo2();
        }
    }



    private void startRecordingVideo2(){
        try {
            //closePreviewSession();
            setUpMediaRecorder();

            //构建输出参数  在参数中设置物理摄像头
            List<OutputConfiguration> configurations = new ArrayList<>();
            mPreviewBuilder = mCameraDevice.createCaptureRequest(CameraDevice.TEMPLATE_RECORD);

            //配置第一个物理摄像头
            SurfaceTexture texture = textureView1.getSurfaceTexture();
            OutputConfiguration outputConfiguration = new OutputConfiguration(new Surface(texture));
            outputConfiguration.setPhysicalCameraId(dualCamera.getPhysicsCameraId1());
            configurations.add(outputConfiguration);
            mPreviewBuilder.addTarget(Objects.requireNonNull(outputConfiguration.getSurface()));

            //配置第2个物理摄像头
            SurfaceTexture texture2 = textureView2.getSurfaceTexture();
            OutputConfiguration outputConfiguration2 = new OutputConfiguration(new Surface(texture2));
            outputConfiguration2.setPhysicalCameraId(dualCamera.getPhysicsCameraId2());
            configurations.add(outputConfiguration2);
            mPreviewBuilder.addTarget(Objects.requireNonNull(outputConfiguration2.getSurface()));

            Surface recorderSurface = mMediaRecorder.getSurface();
            OutputConfiguration outputConfiguration3 = new OutputConfiguration(recorderSurface);
            configurations.add(outputConfiguration3);
            mPreviewBuilder.addTarget(Objects.requireNonNull(outputConfiguration3.getSurface()));

            //注册摄像头
            SessionConfiguration sessionConfiguration = new SessionConfiguration(
                    SessionConfiguration.SESSION_REGULAR,
                    configurations,
                    AsyncTask.SERIAL_EXECUTOR,
                    new CameraCaptureSession.StateCallback() {
                        @Override
                        public void onConfigured(@NonNull CameraCaptureSession cameraCaptureSession) {
                            cameraSession = cameraCaptureSession;
                            updatePreview();
                            context.runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    mIsRecordingVideo = true;
                                    // Start recording
                                    mMediaRecorder.start();
                                }
                            });
                        }
                        @Override
                        public void onConfigureFailed(@NonNull CameraCaptureSession cameraCaptureSession) {
                            if (null != context) {
                                Toast.makeText(context, "Failed", Toast.LENGTH_LONG).show();
                            }
                            startPreview();
                            if (null != mMediaRecorder) {
                                mMediaRecorder.reset();
                                mMediaRecorder.release();
                                mMediaRecorder = null;
                            }
                        }
                    }
            );
            mCameraDevice.createCaptureSession(sessionConfiguration);
        } catch (CameraAccessException | IOException e) {
            e.printStackTrace();
        }
    }

    private void startRecordingVideo() {
        Log.d("yutao", "startRecordingVideo");
        if (null == mCameraDevice || !textureView1.isAvailable() || !textureView2.isAvailable()) {
            return;
        }
        try {
            List<Surface> surfaces = new ArrayList<>();

            //closePreviewSession();
            setUpMediaRecorder();

            //texture.setDefaultBufferSize(mPreviewSize.getWidth(), mPreviewSize.getHeight());
            mPreviewBuilder = mCameraDevice.createCaptureRequest(CameraDevice.TEMPLATE_RECORD);

            SurfaceTexture texture1 = textureView1.getSurfaceTexture();
            assert texture1 != null;
            // Set up Surface for the camera preview
            Surface previewSurface1 = new Surface(texture1);
            surfaces.add(previewSurface1);
            mPreviewBuilder.addTarget(previewSurface1);

            SurfaceTexture texture2 = textureView2.getSurfaceTexture();
            assert texture2 != null;
            // Set up Surface2 for the camera preview
            Surface previewSurface2 = new Surface(texture2);
            surfaces.add(previewSurface2);
            mPreviewBuilder.addTarget(previewSurface2);

            // Set up Surface for the MediaRecorder
            Surface recorderSurface = mMediaRecorder.getSurface();
            surfaces.add(recorderSurface);
            mPreviewBuilder.addTarget(recorderSurface);

            // Start a capture session
            // Once the session starts, we can update the UI and start recording
            mCameraDevice.createCaptureSession(surfaces, new CameraCaptureSession.StateCallback() {

                @Override
                public void onConfigured(@NonNull CameraCaptureSession cameraCaptureSession) {
                    cameraSession = cameraCaptureSession;
                    updatePreview();
                    context.runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            mIsRecordingVideo = true;
                            // Start recording
                            mMediaRecorder.start();
                        }
                    });
                }

                @Override
                public void onConfigureFailed(@NonNull CameraCaptureSession cameraCaptureSession) {
                    if (null != context) {
                        Toast.makeText(context, "Failed", Toast.LENGTH_LONG).show();
                    }
                    startPreview();
                    if (null != mMediaRecorder) {
                        mMediaRecorder.reset();
                        mMediaRecorder.release();
                        mMediaRecorder = null;
                    }
                }
            }, mBackgroundHandler);
        } catch (CameraAccessException | IOException e) {
            e.printStackTrace();
        }

    }

    private void stopRecordingVideo() {
        // UI
        mIsRecordingVideo = false;

        // Stop recording
        mMediaRecorder.stop();
        mMediaRecorder.reset();

        if (null != context) {
            Toast.makeText(context, "Video saved: " + mNextVideoAbsolutePath,
                    Toast.LENGTH_LONG).show();
            Log.d(TAG, "Video saved: " + mNextVideoAbsolutePath);
        }
        mNextVideoAbsolutePath = null;
        startPreview();
    }

    private void setUpMediaRecorder() throws IOException {
        if (null == context) {
            return;
        }
        Size videoSize = getVideoSize();
        //mMediaRecorder.setAudioSource(MediaRecorder.AudioSource.MIC);
        mMediaRecorder.setVideoSource(MediaRecorder.VideoSource.SURFACE);
        mMediaRecorder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);
        if (mNextVideoAbsolutePath == null || mNextVideoAbsolutePath.isEmpty()) {
            mNextVideoAbsolutePath = getVideoFilePath(context);
        }
        mMediaRecorder.setOutputFile(mNextVideoAbsolutePath);
        mMediaRecorder.setVideoEncodingBitRate(10000000);
        mMediaRecorder.setVideoFrameRate(30);
        mMediaRecorder.setVideoSize(videoSize.getWidth(), videoSize.getHeight());
        mMediaRecorder.setVideoEncoder(MediaRecorder.VideoEncoder.H264);
        //mMediaRecorder.setAudioEncoder(MediaRecorder.AudioEncoder.AAC);
        int rotation = context.getWindowManager().getDefaultDisplay().getRotation();
        switch (mSensorOrientation) {
            case SENSOR_ORIENTATION_DEFAULT_DEGREES:
                mMediaRecorder.setOrientationHint(DEFAULT_ORIENTATIONS.get(rotation));
                break;
            case SENSOR_ORIENTATION_INVERSE_DEGREES:
                mMediaRecorder.setOrientationHint(INVERSE_ORIENTATIONS.get(rotation));
                break;
        }
        mMediaRecorder.prepare();
    }

    private void updatePreview() {
        if (null == mCameraDevice) {
            return;
        }
        try {
            setUpCaptureRequestBuilder(mPreviewBuilder);
            HandlerThread thread = new HandlerThread("CameraPreview");
            thread.start();
            cameraSession.setRepeatingRequest(mPreviewBuilder.build(), null, mBackgroundHandler);
        } catch (CameraAccessException e) {
            e.printStackTrace();
        }
    }

    private void setUpCaptureRequestBuilder(CaptureRequest.Builder builder) {
        builder.set(CaptureRequest.CONTROL_MODE, CameraMetadata.CONTROL_MODE_AUTO);
    }

    private String getVideoFilePath(Context context) {
        final File dir = context.getExternalFilesDir(null);
        return (dir == null ? "" : (dir.getAbsolutePath() + "/"))
                + System.currentTimeMillis() + ".mp4";
    }

    private Size getVideoSize(){
        try {
            CameraManager manager = (CameraManager) context.getSystemService(Context.CAMERA_SERVICE);
            CameraCharacteristics characteristics = manager.getCameraCharacteristics(String.valueOf(0));
            StreamConfigurationMap map = characteristics
                    .get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP);
            mSensorOrientation = characteristics.get(CameraCharacteristics.SENSOR_ORIENTATION);
            if (map == null) {
                throw new RuntimeException("Cannot get available preview/video sizes");
            }
            Size mVideoSize = chooseVideoSize(map.getOutputSizes(MediaRecorder.class));
            Log.d("yutao", "videosize: " + mVideoSize.toString());
            return mVideoSize;
        } catch (CameraAccessException e) {
            e.printStackTrace();
        }

        Log.d("yutao", "videosize null");
        return null;
    };

    private static Size chooseVideoSize(Size[] choices) {
        for (Size size : choices) {
            Log.d("yutao", "size: " + size);
            if (size.getWidth() == 1080 && size.getHeight() == 720 ) { // && size.getWidth() <= 1080
                return size;
            }
        }
        Log.e(TAG, "Couldn't find any suitable video size");
        return choices[choices.length - 1];
    }
}
