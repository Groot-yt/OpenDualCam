# camera2
camera 拍照，实时预览demo.
